import sys
import os

# Add your project directory to Python path
path = '/home/yourusername/ai-assessment-system'
if path not in sys.path:
    sys.path.append(path)

# Set environment variables
os.environ['OPENAI_API_KEY'] = 'your_openai_api_key_here'
os.environ['DATABASE_URL'] = 'sqlite:///./ai_assessment.db'
os.environ['ADMIN_PASSWORD'] = 'your_secure_admin_password'

# Import your FastAPI app
from app.main import app

# For WSGI
application = app 