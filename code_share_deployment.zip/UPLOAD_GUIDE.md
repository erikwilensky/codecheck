# PythonAnywhere File Upload Guide

## Method 1: Using PythonAnywhere Console (Recommended)

### Step 1: Create a Zip File Locally

1. **Select your files:**
   - Open your `code_share` folder
   - Select all files and folders (Ctrl+A)
   - Right-click and choose "Send to" → "Compressed (zipped) folder"
   - Name it `code_share.zip`

2. **Verify the zip contains:**
   ```
   code_share.zip
   ├── app/
   ├── static/
   ├── requirements.txt
   ├── wsgi.py
   ├── pythonanywhere_setup.py
   └── ... (all other files)
   ```

### Step 2: Upload to PythonAnywhere

1. **Go to PythonAnywhere Dashboard**
   - Log in to your PythonAnywhere account
   - Click on "Files" tab

2. **Upload the zip file:**
   - Click "Upload a file"
   - Select your `code_share.zip` file
   - Wait for upload to complete

3. **Open a Bash console:**
   - Click on "Consoles" tab
   - Click "Bash" to open a new console

### Step 3: Extract and Organize Files

1. **Navigate to your home directory:**
   ```bash
   cd ~
   ```

2. **List files to confirm upload:**
   ```bash
   ls -la
   ```
   You should see `code_share.zip`

3. **Extract the zip file:**
   ```bash
   unzip code_share.zip
   ```

4. **Verify the extraction:**
   ```bash
   ls -la code_share/
   ```

5. **Check the structure:**
   ```bash
   tree code_share/ || find code_share/ -type f | head -20
   ```

### Step 4: Set Up Your Web App

1. **Go to Web tab in PythonAnywhere**

2. **Create new web app:**
   - Click "Add a new web app"
   - Choose "Manual configuration"
   - Select Python 3.9 or higher

3. **Configure paths:**
   - **Source code:** `/home/yourusername/code_share`
   - **Working directory:** `/home/yourusername/code_share`

4. **Edit the WSGI file:**
   - Click on the WSGI configuration file link
   - Replace contents with:
   ```python
   import sys
   import os
   
   # Add your project directory to Python path
   path = '/home/yourusername/code_share'
   if path not in sys.path:
       sys.path.append(path)
   
   # Set environment variables
   os.environ['OPENAI_API_KEY'] = 'your_actual_openai_api_key'
   os.environ['DATABASE_URL'] = 'sqlite:///./ai_assessment.db'
   os.environ['ADMIN_PASSWORD'] = 'your_secure_admin_password'
   
   # Import your FastAPI app
   from app.main import app
   
   # For WSGI
   application = app
   ```

## Method 2: Using Git (Alternative)

If you have your code in a Git repository:

1. **Open Bash console in PythonAnywhere**

2. **Clone your repository:**
   ```bash
   cd ~
   git clone https://github.com/yourusername/code_share.git
   ```

3. **Follow the same web app configuration steps**

## Method 3: Manual File Upload

1. **Go to Files tab in PythonAnywhere**

2. **Create directory structure:**
   - Click "New directory" → name it `code_share`
   - Navigate into `code_share`
   - Create subdirectories: `app`, `static`

3. **Upload files individually:**
   - Upload each file to the appropriate directory
   - This is more time-consuming but gives you control

## Console Commands for Verification

After uploading, run these commands to verify everything is correct:

```bash
# Navigate to your project
cd ~/code_share

# Check file structure
ls -la

# Check if all directories exist
ls -la app/
ls -la static/

# Check if key files exist
ls -la requirements.txt wsgi.py pythonanywhere_setup.py

# Check Python can import your app
python -c "import app.main; print('✅ App imports successfully')"

# Run setup script
python pythonanywhere_setup.py
```

## Troubleshooting Upload Issues

### Common Problems:

1. **Zip file too large:**
   - Remove unnecessary files (like `__pycache__`, `.git`)
   - Create a smaller zip with only essential files

2. **Permission errors:**
   ```bash
   chmod -R 755 ~/code_share
   ```

3. **Missing files:**
   - Check if all files uploaded correctly
   - Re-upload missing files individually

4. **Import errors:**
   - Verify the path in wsgi.py matches your actual path
   - Check that all `__init__.py` files exist

## Quick Verification Checklist

After upload, verify:
- [ ] All files are in `/home/yourusername/code_share/`
- [ ] `app/` directory contains all Python files
- [ ] `static/` directory contains HTML files
- [ ] `requirements.txt` exists
- [ ] `wsgi.py` exists and is configured
- [ ] `pythonanywhere_setup.py` exists

## Next Steps After Upload

1. **Install dependencies:**
   ```bash
   cd ~/code_share
   pip install --user -r requirements.txt
   ```

2. **Set environment variables** in Web tab

3. **Run setup script:**
   ```bash
   python pythonanywhere_setup.py
   ```

4. **Reload your web app**

5. **Test your domain:** https://codecheck.website 